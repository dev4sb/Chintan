<?php



ini_set('memory_limit','256M');

require '../vendor/autoload.php';
require 'helpers.php';
require 'config.php';
require 'Database.php';

/* ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);    */


date_default_timezone_set('Asia/Kolkata');

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use Slim\Http\UploadedFile;

function connectdb(){
    $db = new Database(DB_NAME, DB_USERNAME, DB_PASSWORD, DB_HOST); 
    return  $db;
}

$dotenv = new Dotenv\Dotenv(__DIR__ . str_repeat(DIRECTORY_SEPARATOR . '..', 2));
$dotenv->load();

/*$config = [
    'apiKey' => $_ENV['API_KEY'],
    'secret' => $_ENV['SECRET'],
    'host' => $_ENV['HOST']
];*/
$config = [
    'apiKey' => $_ENV['API_KEY'],
    'secret' => $_ENV['SECRET'],
    'host' => $_ENV['HOST'],
    'settings' => [
    // Slim Settings
    'determineRouteBeforeAppMiddleware' => true,
    'displayErrorDetails' => true,
    'addContentLengthHeader' => false]
];
$app = new \Slim\App($config);

$container = $app->getContainer();
$container['upload_directory'] = __DIR__ . '/uploads';




function getAccessTokenfromDB($shop){

    $db = connectdb();
    $db->select("csp_sf-stores",array("domain_name"=>$shop));
    $shop =$db->result_array();
    $access_token = $shop[0]['access_token'];
    return $access_token;
}

 
$app->get('/redirectInLiuqidfile', function ($request, $response) {
       $db = connectdb();
   
    $params = $request->getQueryParams();
    
    });


$app->run();
