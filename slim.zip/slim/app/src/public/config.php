<?php 

/**
 * Database configuration
 */
define('DB_USERNAME', 'setubri2_allshopifyapps');
define('DB_PASSWORD', 'QVeT7Ki!@^bS');
define('DB_HOST', 'localhost');
define('DB_NAME', 'setubri2_allshopifyapps');
define('BASE_URL', 'https://www.setubridgeapps.com/coming-soon-product/app/src/public');
define('ADMIN_BASE_URL', 'https://www.setubridgeapps.com/coming-soon-product/app/admin');

?>
